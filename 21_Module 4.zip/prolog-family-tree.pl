/* Facts */
male(travis).
male(zayn).
male(drake).
male(harry).
male(daniel).
male(tom).
female(kylie).
female(eva).
female(rubi).
female(kendall).
 
parent_of(travis,rubi).
parent_of(travis,kendall).
parent_of(kylie, rubi).
parent_of(kylie, kendall).
parent_of(zayn,tom).
parent_of(eva, tom).
parent_of(rubi, daniel).
parent_of(drake, daniel).
parent_of(kendall, tom).
parent_of(harry, tom).
 
/* Rules */
father_of(X,Y):- male(X),
    parent_of(X,Y).
 
mother_of(X,Y):- female(X),
    parent_of(X,Y).
 
grandfather_of(X,Y):- male(X),
    parent_of(X,Z),
    parent_of(Z,Y).
 
grandmother_of(X,Y):- female(X),
    parent_of(X,Z),
    parent_of(Z,Y).
 
sister_of(X,Y):- %(X,Y or Y,X)%
    female(X),
    father_of(F, Y), father_of(F,X),X \= Y.
 
sister_of(X,Y):- female(X),
    mother_of(M, Y), mother_of(M,X),X \= Y.
 
aunt_of(X,Y):- female(X),
    parent_of(Z,Y), sister_of(Z,X),!.
 
brother_of(X,Y):- %(X,Y or Y,X)%
    male(X),
    father_of(F, Y), father_of(F,X),X \= Y.
 
brother_of(X,Y):- male(X),
    mother_of(M, Y), mother_of(M,X),X \= Y.
 
uncle_of(X,Y):-
    parent_of(Z,Y), brother_of(Z,X).

ancestor_of(X,Y):- parent_of(X,Y).
ancestor_of(X,Y):- parent_of(X,Z),
    ancestor_of(Z,Y).